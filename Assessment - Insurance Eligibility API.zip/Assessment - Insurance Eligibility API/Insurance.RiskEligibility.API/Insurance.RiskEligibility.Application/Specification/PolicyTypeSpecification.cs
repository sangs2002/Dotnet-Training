﻿namespace Insurance.RiskEligibility.Application.Specification
{
    public class PolicyTypeSpecification : ISpecification<EligibilityRequest>
    {
        public string ErrorMessage => "Unsupported policy type.";

        public bool IsValid(EligibilityRequest entity)
        {
            return Enum.IsDefined(typeof(PolicyType), entity.PolicyType);
        }
    }
}
