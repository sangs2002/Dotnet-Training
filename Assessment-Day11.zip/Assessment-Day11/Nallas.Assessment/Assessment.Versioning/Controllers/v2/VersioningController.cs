﻿using Microsoft.AspNetCore.Mvc;

namespace Assessment.Versioning.Controllers.v2
{
    [ApiController]
    [ApiVersion("2.0")]
    [Route("api/v{version:apiVersion}/policy")]

    public class VersioningController : ControllerBase
    {
        [HttpGet]

        public IActionResult Get()
        {
            return Ok(new
            {

                Version = "v1",
                PolicyType = "Basic",
                Coverage = "Limited",
                ClaimSupport = true
            });
        
        }

    }
}
