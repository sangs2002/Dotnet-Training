﻿using Microsoft.AspNetCore.Mvc;

namespace Assessment.Versioning.Controllers.v1
{
    [ApiController]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/policy")]


    public class VersioningController : ControllerBase
    {
        [HttpGet]
        public IActionResult Get()
        {
            return Ok(new
            {
                Version = "v1",
                PolicyType = "Basic",
                Coverage = "Limited"
            });
        }
    }
}
