using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ApiExplorer;
using Microsoft.AspNetCore.Mvc.Versioning;


var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();

builder.Services.AddApiVersioning(options =>
{
    options.DefaultApiVersion = new ApiVersion(1, 0);
    options.AssumeDefaultVersionWhenUnspecified = true;
    options.ReportApiVersions = true;
    //url
    //options.ApiVersionReader = new UrlSegmentApiVersionReader();
    //options.ApiVersionReader =
    //query
    //new QueryStringApiVersionReader("api-version");
    ////header
    options.ApiVersionReader =
      new HeaderApiVersionReader("X-API-Version");
});

//cors
builder.Services.AddCors(options =>
{
    options.AddPolicy("Policy", options =>
    {
        options.AllowAnyHeader()
        .AllowAnyMethod()
                    .WithOrigins("http://localhost:4200");

});
});
builder.Services.AddSwaggerGen();
builder.Services.AddVersionedApiExplorer(options =>
{
    options.GroupNameFormat = "'v'VVV";
    options.SubstituteApiVersionInUrl = true;

});

var app = builder.Build();
app.UseSwagger();

app.UseSwaggerUI(options =>
{
    var provider = app.Services
        .GetRequiredService<Microsoft.AspNetCore.Mvc.ApiExplorer.IApiVersionDescriptionProvider>();

    foreach (var description in provider.ApiVersionDescriptions)
    {
        options.SwaggerEndpoint(
            $"/swagger/{description.GroupName}/swagger.json",
            description.GroupName.ToUpperInvariant());
    }
});


app.UseHttpsRedirection();

app.UseCors("AllowFrontend");

app.UseAuthorization();


app.MapControllers();

app.Run();
