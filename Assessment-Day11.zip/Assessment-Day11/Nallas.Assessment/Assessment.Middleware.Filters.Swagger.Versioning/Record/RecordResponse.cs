﻿namespace Assessment.Middleware.Filters.Swagger.Versioning.Record
{
    public record RecordResponse
    (
        bool IsEligible,
        int Score,
        string tier
        
    );
}
