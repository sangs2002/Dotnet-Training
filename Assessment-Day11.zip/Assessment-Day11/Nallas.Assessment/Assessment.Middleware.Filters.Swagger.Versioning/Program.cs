﻿using Assessment.Middleware.Filters.Swagger.Versioning.Record;

class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("record");

        RecordResponse recordResponse = new RecordResponse(
           IsEligible: true,
          Score: 90,
         tier: "High");

        Console.WriteLine(recordResponse);

    }
}