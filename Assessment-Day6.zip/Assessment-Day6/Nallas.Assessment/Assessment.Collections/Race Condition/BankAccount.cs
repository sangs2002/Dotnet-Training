﻿namespace Assessment.Collections.Race_Condition
{
    public class BankAccount
    {
        public int Balance = 1000;

        private readonly object _lock = new object();

        public void Withdraw(int amount)
        {
            if (Balance >= amount)
            {
                Balance -= amount;
            }
        }


        //avoid the race conditions using lock
        public void WithdrawFix(int amount)
        {
            lock (_lock)
            {
                if (Balance >= amount)
                {
                    Balance -= amount;
                }
            }
        }
    }
}
