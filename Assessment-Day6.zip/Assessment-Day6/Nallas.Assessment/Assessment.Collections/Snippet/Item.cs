﻿namespace Assessment.Collections.Snippet
{
    public class Item
    {
        public int Id { get; set; }
        public string Type { get; set; }
        public bool IsActive { get; set; }

    }
}
