﻿using System.IO;

namespace Assessment.Collections.Snippet
{
    public class Linq
    {
        
        public void Linqsnippet()
        {
            var data = new List<Item>
            {
   
                new Item { Id = 3, Type = "A", IsActive = false },
                new Item { Id = 5, Type = "B", IsActive = true },
                new Item { Id = 7, Type = "C", IsActive = true }
            };
            var result = data.Where(x => x.IsActive).GroupBy(x => x.Type)
            .Select(g => new
            {
                Type = g.Key,
                Count = g.Count()
            })
            .ToList();


            int total = 0;

            async Task AddAsync()
            {
                int temp = total;
                await Task.Delay(100);
                total = temp + 1;
            }

        }
    }
}
