﻿using Assessment.Collections.Collections;
using Assessment.Collections.Race_Condition;

class Program
{
    public static void Main(string[] args)
    {

        var account = new BankAccount();

        Parallel.For(0, 10, i =>
        {
            account.Withdraw(200);
        });

        Console.WriteLine(account.Balance);


        //Collections

        Non_Generic.ArrayList();
        Non_Generic.Hashtable();
        Non_Generic.Hashtable();
        Non_Generic.Stack();
        Non_Generic.SortedList();


       GenricCollections.Array();
        GenricCollections.List();
        GenricCollections.Dictionary();
        GenricCollections.HashSet();
        GenricCollections.Queue();
        GenricCollections.Stack();

    }
}