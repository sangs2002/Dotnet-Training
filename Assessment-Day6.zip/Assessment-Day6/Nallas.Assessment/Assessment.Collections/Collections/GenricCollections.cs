﻿namespace Assessment.Collections.Collections
{
    public static class GenricCollections
    {
        public static void Array()
        {
            int[] retryIntervals = { 1, 3, 5 };
            Console.WriteLine(retryIntervals[1]);
        }
        public static void List()
        {
            List<string> products = new List<string>(){ "laptop", "mobile" };
            products.Add("phone");
            Console.WriteLine(products[2]);
        }
        public static void Dictionary()
        {
            Dictionary<int, string> users = new Dictionary<int, string>();
            users[1] = "admin";
            users[2] = "user";

            Console.WriteLine(users[1]);
        }

        public static void HashSet()
        {
            HashSet<string> emails = new HashSet<string>();
            emails.Add("sangs@email.com");
            emails.Add("sangs@email.com");

            Console.WriteLine(emails.Count);
        }
        public static void Queue()
        {
            Queue<string> orders = new Queue<string>();
            orders.Enqueue("1");
            orders.Enqueue("2");

            Console.WriteLine(orders.Dequeue());
        }
        public static void Stack()
        {
            Stack<string> undo = new Stack<string>();
            undo.Push("1");
            undo.Push("2");

            Console.WriteLine(undo.Pop());
        }


    }
}
