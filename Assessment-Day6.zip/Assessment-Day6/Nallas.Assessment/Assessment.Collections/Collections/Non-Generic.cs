﻿using System.Collections;

namespace Assessment.Collections.Collections
{
    public class Non_Generic
    {
       public static void ArrayList()
        {
            ArrayList list = new ArrayList();

            list.Add(10);
            list.Add("Hello");
            list.Add(5.5);

            int value = (int)list[0];  
            Console.WriteLine(value);
        }

        public static void Hashtable()
        {
            Hashtable users = new Hashtable();

            users.Add(1, "Admin");
            users.Add("role", "Manager");

            Console.WriteLine(users[1]);
            Console.WriteLine(users["role"]);
        }

       public static void Queue()
        {
            Queue queue = new Queue();

            queue.Enqueue("1");
            queue.Enqueue("2");

            Console.WriteLine(queue.Dequeue()); 
        }

       public static void Stack()
        {
            Stack stack = new Stack();

            stack.Push("1");
            stack.Push("2");

            Console.WriteLine(stack.Pop()); 
        }

       public static void SortedList()
        {
            SortedList scores = new SortedList();

            scores.Add(90, "Alice");
            scores.Add(70, "Bob");

            Console.WriteLine(scores.GetByIndex(0)); 
        }
    }
}
