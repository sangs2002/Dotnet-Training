﻿namespace Assessment.Async_Advanced.Tasks
{
    public class Run
    {
        public async void Await()
        {
            Console.WriteLine($"Main started on Thread: {Thread.CurrentThread.ManagedThreadId}");

            await Task.Run(() =>
            {
                Console.WriteLine($"Task.Run started on Thread: {Thread.CurrentThread.ManagedThreadId}");
                Thread.Sleep(3000);
                Console.WriteLine($"Task.Run finished on Thread: {Thread.CurrentThread.ManagedThreadId}");
            });

            Console.WriteLine($"Main resumed on Thread: {Thread.CurrentThread.ManagedThreadId}");
        }

        public async void WithoutAwait()
        {
            Console.WriteLine($"Main thread: {Thread.CurrentThread.ManagedThreadId}");

            Task.Run(() =>
            {
                Console.WriteLine($"Task running on Thread: {Thread.CurrentThread.ManagedThreadId}");
                Thread.Sleep(2000);
            });

            Console.WriteLine("Main ends");
        }

    }
}
