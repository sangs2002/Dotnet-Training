﻿namespace Assessment.Async_Advanced.Tasks
{
    public class wait
    {

        public void Taskwait()
        {
            Console.WriteLine($"Main started on Thread {Thread.CurrentThread.ManagedThreadId}");

            Task task = Task.Run(() =>
            {
                Console.WriteLine($"Task running on Thread {Thread.CurrentThread.ManagedThreadId}");
                Thread.Sleep(3000);
                Console.WriteLine("Task finished");
            });

            task.Wait(); 

            Console.WriteLine("Main resumed after Task.Wait()");
        }
    }
}
