﻿namespace Assessment.Async_Advanced.Tasks
{
    public class Result
    {

        public void Results()
        {
            Console.WriteLine($"Main Thread: {Thread.CurrentThread.ManagedThreadId}");

            Task<int> task = Task.Run(() =>
            {
                Console.WriteLine($"Task running on Thread: {Thread.CurrentThread.ManagedThreadId}");
                Thread.Sleep(3000);
                return 42;
            });

            int result = task.Result; 

            Console.WriteLine($"Result: {result}");
        }
    }
}
