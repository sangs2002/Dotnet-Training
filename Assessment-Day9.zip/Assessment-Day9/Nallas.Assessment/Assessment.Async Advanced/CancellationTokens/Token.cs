﻿namespace Assessment.Async_Advanced.CancellationTokens
{
    public class Token
    {

        public async Task Tokens(CancellationToken tokens)
        {
            for (int i = 1; i <= 10; i++)
            {
                tokens.ThrowIfCancellationRequested();

                Console.WriteLine(i);
                await Task.Delay(1000);
            }
        }
    }
}
