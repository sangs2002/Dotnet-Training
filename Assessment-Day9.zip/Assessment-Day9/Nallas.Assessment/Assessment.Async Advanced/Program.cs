﻿using Assessment.Async_Advanced.CancellationTokens;
using Assessment.Async_Advanced.Configureawait;
using Assessment.Async_Advanced.Tasks;
using System.Threading.Tasks;

class Program
{
   public static async Task Main(string[] args)
    {
        //Run run = new Run();
        //run.Await();
        //run.WithoutAwait();

        //wait wait = new wait();
        //wait.Taskwait();

        //Result result = new Result();
        //result.Results();

        AwaitFalse awaitFalse = new AwaitFalse();
        awaitFalse.False();


        var cts = new CancellationTokenSource();

        Token token = new Token();

       Task wait = token.Tokens(cts.Token);

        await Task.Delay(3000);

        cts.Cancel();

        try
        {
            await wait;
        }
        catch (OperationCanceledException)
        {

            Console.WriteLine("Task was cancelled");
        }


    }

}