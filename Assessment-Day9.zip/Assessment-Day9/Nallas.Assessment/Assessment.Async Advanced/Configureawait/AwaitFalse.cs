﻿using System.Threading.Tasks;

namespace Assessment.Async_Advanced.Configureawait
{
    public class AwaitFalse
    {
        public async Task False()
        {
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId);

            await Task.Delay(1000).ConfigureAwait(true);

            Console.WriteLine(Thread.CurrentThread.ManagedThreadId);

        }
    }
}
