﻿namespace Assessment.DI.DI
{
    public interface IChefService
    {
        void Dish(IDishes dishes);
    }
}
