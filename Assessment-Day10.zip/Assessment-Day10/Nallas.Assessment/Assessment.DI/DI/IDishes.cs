﻿namespace Assessment.DI.DI
{
    public interface IDishes
    {

    }

}
