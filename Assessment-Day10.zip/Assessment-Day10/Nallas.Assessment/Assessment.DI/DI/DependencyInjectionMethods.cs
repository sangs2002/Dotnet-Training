﻿namespace Assessment.DI.DI
{
    public class DependencyInjectionMethods
    {


        // Constructor

        private readonly ChefService _chefservice;

        public DependencyInjectionMethods(ChefService chefService)
        {
            _chefservice = chefService;
        }

        public void Dish()
        {
            _chefservice.Dinner("Dosa");
        }

        //Property

        public ChefService ChefService { get; set; }

        public void Dish2()
        {
            ChefService.Dinner("Itly");
        }


        //Method 

        public void Dish(ChefService chefService)
        {
            chefService.Dinner("Chappathi");
        }

        //Interface

        public class Interfaces : IChefService
        {
            private IDishes _dishes;
            public void Dish(IDishes dishes)
            {
               _dishes = dishes;
            }


        }
    }
}
