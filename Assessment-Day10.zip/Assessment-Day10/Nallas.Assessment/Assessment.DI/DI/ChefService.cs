﻿
namespace Assessment.DI.DI
{
    public class ChefService
    {
        public void Dinner(string message)
        {
            Console.WriteLine($"Dinner is {message}");
        }
    }
}
