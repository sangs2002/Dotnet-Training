﻿namespace Assessment.DI.Concurrency
{
    public class Without
    {
        public static void DoWork(int id)
        {
            Console.WriteLine($"Task {id} started");
            Thread.Sleep(2000);
            Console.WriteLine($"Task {id} finished");
        }
    }
}
