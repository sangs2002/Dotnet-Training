﻿namespace Assessment.DI.Concurrency
{
    public class With
    {
        public static async Task DoWorkAsync(int id)
        {
            Console.WriteLine($"Task {id} started");
           await Task.Delay(2000);
            Console.WriteLine($"Task {id} finished");
        }
    }
}
