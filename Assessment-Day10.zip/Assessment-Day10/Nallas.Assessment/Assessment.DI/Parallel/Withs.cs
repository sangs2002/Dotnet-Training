﻿
namespace Assessment.DI.Parallel
{
    public class Withs
    {
       public static void DoCalculations(int id)
        {
            Console.WriteLine($"Calculation {id} started on Thread {Thread.CurrentThread.ManagedThreadId}");
            Thread.Sleep(2000);
            Console.WriteLine($"Calculation {id} finished");
        }
    }
}
