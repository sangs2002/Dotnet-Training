﻿using Assessment.DI.Concurrency;
using Assessment.DI.Parallel;
using System.Diagnostics;

class Program
{
    static async Task Main()
    {
        //without Concurrency amd parallel
        Console.WriteLine("Without Concurrency");

        Stopwatch stopwatch = Stopwatch.StartNew();

        Without.DoWork(1);
        Without.DoWork(2);
        Without.DoWork(3);

        stopwatch.Stop();

        Console.WriteLine($"Total Time: {stopwatch.Elapsed.TotalSeconds} seconds");


        //Concurrency
        Console.WriteLine("Wih Concurrency");

        Stopwatch stopwatch2 = Stopwatch.StartNew();

        Task task = Assessment.DI.Concurrency.With.DoWorkAsync(1);
        Task task2 = Assessment.DI.Concurrency.With.DoWorkAsync(2);
        Task task3 = Assessment.DI.Concurrency.With.DoWorkAsync(3);


        await Task.WhenAll(task, task2, task3);
        stopwatch2.Stop();

        Console.WriteLine($"Total Time: {stopwatch2.Elapsed.TotalSeconds} seconds");


        //Parallel

        Console.WriteLine("With Parallel");

        Stopwatch stopwatch3 = Stopwatch.StartNew();

        Parallel.For(1, 10, i =>
        {
             Withs.DoCalculations(i);

        });

        stopwatch3.Stop();

        Console.WriteLine($"Total Time: {stopwatch3.Elapsed.TotalSeconds} seconds");


    }
}