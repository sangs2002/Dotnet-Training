﻿namespace ClientEvaluationSystem.Enum
{
    public enum RiskType
    {
        high,
        low,
    }
}
