﻿namespace ClientEvaluationSystem.Enum
{
    public enum TierType
    {
        NotEligible = 0,
        StandardTier = 1,
        SeniorTier = 2,
        CareTier = 3,
        FamilyTier = 4,
        PremiumTier = 5,
    }
}
