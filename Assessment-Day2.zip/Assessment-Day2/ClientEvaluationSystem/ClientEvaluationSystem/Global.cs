﻿
global using ClientEvaluationSystem.Helper;
global using ClientEvaluationSystem.Model;
global using ClientEvaluationSystem.Constants;
global using ClientEvaluationSystem.Enum;
global using ClientEvaluationSystem.Interface;
global using ClientEvaluationSystem.Service.Implementation;
global using ClientEvaluationSystem.Data;
global using ClientEvaluationSystem.Service;