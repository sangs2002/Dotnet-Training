﻿using ClientEvaluationSystem.Enum;

namespace ClientEvaluationSystem.Model
{
    public class Person
    {
        public string Name { get; set; }

        public int Age { get; set; }

        public bool HasHealthChallenges { get; set; }

        public int NumberOfDependents { get; set; }

        public decimal AnnualIncome { get; set; }

        public bool HasPreviousClaims { get; set; }

        public TierType ClientTier { get; set; }

        public RiskType RiskLevel { get; set; }

        public Person(string name, int age, bool _HasHealthChallenges, int _NumberOfDependents, decimal annualIncome, bool _HasPreviousClaims)
        {
            Name = name;
            Age = age;
            HasHealthChallenges = _HasHealthChallenges;
            NumberOfDependents = _NumberOfDependents;
            AnnualIncome = annualIncome;
            HasPreviousClaims = _HasPreviousClaims;
        }

    }
}
