﻿namespace ClientEvaluationSystem.Model
{
    public class EligibilityCheck
    {
        public string? IsEligible { get; set; }
    }
}
