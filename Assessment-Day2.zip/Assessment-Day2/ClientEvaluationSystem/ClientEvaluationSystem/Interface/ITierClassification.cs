﻿namespace ClientEvaluationSystem.Interface
{
    public interface ITierClassification
    {
        bool CheckTier(Person person, InsurancePlanConfig insuranceplanconfig);

        TierType GetTierType();
    }
}
