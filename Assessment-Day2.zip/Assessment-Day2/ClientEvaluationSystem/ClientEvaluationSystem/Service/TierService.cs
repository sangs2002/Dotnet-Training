﻿namespace ClientEvaluationSystem.Service
{
    public class TierService
    {
        private readonly List<ITierClassification> tierClassifications;
        private readonly InsurancePlanConfig _insuranceplanconfig;

        public TierService(InsurancePlanConfig insuranceplanconfig)
        {
            _insuranceplanconfig = insuranceplanconfig;
            tierClassifications = new List<ITierClassification>
            {
                new TierRules.SeniorTier(),
                new TierRules.CareTier(),
                new TierRules.FamilyTier(),
                new TierRules.PreminumTier()
            };
        }

        public TierType EvaluateClient(Person person)
        {

            foreach (var tierClassification in tierClassifications)
            {
                if (tierClassification.CheckTier(person, _insuranceplanconfig))
                {
                    return tierClassification.GetTierType();
                }

            }
            return TierType.StandardTier;

        }

    }

}
