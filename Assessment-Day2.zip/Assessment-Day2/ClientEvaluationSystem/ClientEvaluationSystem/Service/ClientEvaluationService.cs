﻿namespace ClientEvaluationSystem.Service
{
    public class ClientEvaluationService
    {
        public virtual string IsEligible(
               Person person,
               EligibilityCheck eligibilityCheck,
               InsurancePlanConfig helper)
        {
            return eligibilityCheck.IsEligible;
        }

        public virtual TierType DownGradeTier(Person person, InsurancePlanConfig insuranceplanconfig)
        {
            return person.ClientTier;
        }

        public virtual RiskType GetRiskType(Person person)
        {
            return person.RiskLevel;
        }
    }
}
