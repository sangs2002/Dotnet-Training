﻿namespace ClientEvaluationSystem.Service.Implementation
{
    public class TierRules
    {

        public class SeniorTier : ITierClassification
        {
            public bool CheckTier(Person person, InsurancePlanConfig insuranceplanconfig)
            {
                return person.Age >= insuranceplanconfig.SeniorAge;
            }

            public TierType GetTierType()
            {
                return TierType.SeniorTier;
            }
        }

        public class CareTier : ITierClassification
        {
            public bool CheckTier(Person person, InsurancePlanConfig insuranceplanconfig)
            {
                return person.HasHealthChallenges;
            }

            public TierType GetTierType()
            {
                return TierType.CareTier;
            }
        }

        public class FamilyTier : ITierClassification
        {
            public bool CheckTier(Person person, InsurancePlanConfig insuranceplanconfig)
            {
                return person.NumberOfDependents > insuranceplanconfig.FamilyDependents;
            }

            public TierType GetTierType()
            {
                return TierType.FamilyTier;
            }
        }


        public class PreminumTier : ITierClassification
        {
            public bool CheckTier(Person person, InsurancePlanConfig insuranceplanconfig)
            {
                return person.AnnualIncome > insuranceplanconfig.PremiumIncome;
            }

            public TierType GetTierType()
            {
                return TierType.PremiumTier;
            }
        }
    }
}
