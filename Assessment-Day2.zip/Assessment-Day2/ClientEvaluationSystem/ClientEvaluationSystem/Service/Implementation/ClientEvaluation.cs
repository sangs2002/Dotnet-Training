﻿namespace ClientEvaluationSystem.Service.Implementation
{
    public class ClientEvaluation: ClientEvaluationService
    {
        public override RiskType GetRiskType(Person person)
        {
            if(person == null)
            {
                throw new ArgumentNullException(nameof(person), "Person object cannot be null.");
            }

            if(person.HasHealthChallenges == true && person.HasPreviousClaims == true)
            {
                return RiskType.high;
            }

            return RiskType.low;

        }

        public override TierType DownGradeTier(Person person, InsurancePlanConfig insuranceplanconfig)
        {
            base.DownGradeTier(person,insuranceplanconfig);

            if (person == null)
            {
                throw new ArgumentNullException(nameof(person), "Person object cannot be null.");
            }

            if(person.HasPreviousClaims == true && person.Age >= insuranceplanconfig.DownGradeAgeLimit)
            {
                person.ClientTier -= 1;
            }

            return person.ClientTier;  
        }

        public override string IsEligible(Person person, EligibilityCheck eligibilityCheck, InsurancePlanConfig helper)
        {
            if (person == null)
            {
                throw new ArgumentNullException(nameof(person), "Person object cannot be null.");
            }
            else if (person.Age < helper.MinAge || person.Age > helper.MaxAge)
            {

                return eligibilityCheck.IsEligible = ClientConstants.Not_eligible;
            }

            eligibilityCheck.IsEligible = ClientConstants.Eligible;

            return eligibilityCheck.IsEligible;
        }
    }
}
