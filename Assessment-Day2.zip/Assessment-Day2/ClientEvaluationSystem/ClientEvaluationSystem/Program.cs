﻿class Program
{
    static void Main(string[] args)
    {
        var config = new InsurancePlanConfig();
        var persons = new PersonDb().Seed();
        ClientEvaluationService evaluator = new ClientEvaluation();

        foreach (var person in persons)
        {
           evaluator.IsEligible(person, new EligibilityCheck(), config);
        }

        ClientEvaluationService evaluation = new ClientEvaluation();
        var Tier = new TierService(config);

        foreach (var person in persons)
        {
            person.ClientTier = Tier.EvaluateClient(person);
            person.ClientTier = evaluator.DownGradeTier(person, config);
            person.RiskLevel = evaluator.GetRiskType(person);
        }

        var personcount = persons.Where(K=> K.Age < config.MaxAge && K.Age > config.MinAge).ToList();

        if (personcount.Count() > 0)
        {
            foreach (var person in persons)
            {
                Console.WriteLine($"Name: {person.Name}, Age: {person.Age}, Eligible: {person.ClientTier}, Risk Level: {person.RiskLevel}");
            }
        }

    }
}