﻿namespace ClientEvaluationSystem.Helper
{
    public class InsurancePlanConfig
    {
        public int MinAge { get; init; } = ClientConstants.MinAge;
        public int MaxAge { get; init; } = ClientConstants.MaxAge;
        public int SeniorAge { get; init; } = ClientConstants.SeniorAge;
        public int FamilyDependents { get; init; } = ClientConstants.FamilyDependents;
        public decimal PremiumIncome { get; init; } = ClientConstants.PremiumIncome;

        public int DownGradeAgeLimit { get; init; } = ClientConstants.DowngradeAgeLimit;
    }
}
