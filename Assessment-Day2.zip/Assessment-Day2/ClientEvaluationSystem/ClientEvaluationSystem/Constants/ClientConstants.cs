﻿namespace ClientEvaluationSystem.Constants
{
    public class ClientConstants
    {
        public const int MinAge = 18;
        public const int MaxAge = 75;
        public const int SeniorAge = 60;
        public const int FamilyDependents = 3;
        public const int DowngradeAgeLimit = 40;
        public const decimal PremiumIncome = 100000m;
        public const string Not_eligible = "Not Eligible";
        public const string Eligible = "Eligible";
    }
}
