﻿global using Nallas.Assessment.Domain.Models;
global using Nallas.Assessment.Application.DTOs;

