﻿namespace Nallas.Assessment.Domain.Interface
{
    public interface IPaymentService
    {
        void Processpayment(string paymentType);
    }
}
