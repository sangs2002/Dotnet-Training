﻿using Microsoft.EntityFrameworkCore;namespace Nallas.Assessment.Domain.Interface
{
    public interface IApplicationDbContext
    {
        DbSet<Invoice> invoices { get; set; }
    }
}
