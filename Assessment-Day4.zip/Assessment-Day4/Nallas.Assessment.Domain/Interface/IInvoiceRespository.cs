﻿namespace Nallas.Assessment.Domain.Interface
{
    public interface IInvoiceRespository
    {
       public Task AddAsync(Invoice invoice);
    }
}
