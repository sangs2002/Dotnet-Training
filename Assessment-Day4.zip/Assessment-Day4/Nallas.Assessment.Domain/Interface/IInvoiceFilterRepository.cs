﻿namespace Nallas.Assessment.Domain.Interface
{
    public interface IInvoiceFilterRepository
    {
        List<Invoice> FilterInvoice(InvoiceFilter invoiceFilter);
    }
}
