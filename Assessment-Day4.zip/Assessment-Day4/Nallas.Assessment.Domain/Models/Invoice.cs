﻿namespace Nallas.Assessment.Domain.Models
{
    public class Invoice
    {
        public int Id { get; set; }
        public double Amount { get; set; }
        public string? InvoiceName { get; set; }
        public string? InvoiceType { get; set; }
        public DateTime? orderdate { get; set; }

    }
}
