﻿namespace Nallas.Assessment.Domain.Constants
{
    public class PaymentConstants
    {

        public const string CreditCard = "CreditCard";
        public const string Cash = "Cash";
        public const string UPI = "UPI";

    }
}
