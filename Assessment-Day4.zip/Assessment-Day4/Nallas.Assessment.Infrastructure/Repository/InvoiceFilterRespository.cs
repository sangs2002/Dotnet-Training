﻿using Nallas.Assessment.Application.DTOs;

namespace Nallas.Assessment.Infrastructure.Repository
{
    public class InvoiceFilterRespository : IInvoiceFilterRepository
    {
        private readonly IApplicationDbContext _applicationDbContext;

        public InvoiceFilterRespository(IApplicationDbContext applicationDbContext)
        {
            _applicationDbContext = applicationDbContext;
        }

        public List<Invoice> FilterInvoice(InvoiceFilter invoiceFilter)
        {
            IQueryable<Invoice> query = _applicationDbContext.invoices;

            if (invoiceFilter.FromDate.HasValue)
            {
                query = query.Where(date => date.orderdate >= invoiceFilter.FromDate);
            }

            if (invoiceFilter.ToDate.HasValue)
            {
                query = query.Where(date => date.orderdate >= invoiceFilter.ToDate);
            }

            if (!string.IsNullOrWhiteSpace(invoiceFilter.InvoiceName))
            {
                query = query.Where(c => c.InvoiceName.Contains(invoiceFilter.InvoiceName));
            }

            if (invoiceFilter.amount.HasValue)
            {
                query = query.Where(c => c.Amount == invoiceFilter.amount);
            }

            return query.ToList();
        }
    }
}
