﻿namespace Nallas.Assessment.Infrastructure.Repository
{
    public class InvoiceRepository : IInvoiceRespository
    {
        private readonly IApplicationDbContext _appDbContext;
        public InvoiceRepository(IApplicationDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task AddAsync(Invoice invoice)
        {
            await _appDbContext.invoices.AddAsync(invoice);
        }

        public void SaveToDatabase()
        {
            var db = _appDbContext.invoices.Where(k => k.Amount > 100);

            foreach(var invoice in db)
            {
                Console.WriteLine($"Saving {invoice} to DB");

            }
          
        }
    }
}
