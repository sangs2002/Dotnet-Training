﻿namespace Nallas.Assessment.Infrastructure.PaymentType.Implementation
{
    public class PaymentTypeService
    {

        public class CreditCard : IPaymentService
        {
            public void Processpayment(string paymentType)
            {

                if (paymentType == PaymentConstants.CreditCard)
                {
                    Console.WriteLine("Processing Credit card payment");
                }
            }
        }

        public class Cash : IPaymentService
        {
            public void Processpayment(string paymentType)
            {

                if (paymentType == PaymentConstants.Cash)
                {
                    Console.WriteLine("Processing cash payment");
                }
            }
        }

        public class UPI : IPaymentService
        {
            public void Processpayment(string paymentType)
            {

                if (paymentType == PaymentConstants.UPI)
                {
                    Console.WriteLine("Processing UPI payment");
                }
            }
        }

        //May later we can add Paypal


    }
}
