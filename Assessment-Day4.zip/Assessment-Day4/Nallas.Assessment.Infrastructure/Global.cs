﻿global using Nallas.Assessment.Domain.Constants;
global using Microsoft.EntityFrameworkCore;
global using Nallas.Assessment.Domain.Models;
global using Nallas.Assessment.Domain.Interface;
global using Nallas.Assessment.Infrastructure.Data;


