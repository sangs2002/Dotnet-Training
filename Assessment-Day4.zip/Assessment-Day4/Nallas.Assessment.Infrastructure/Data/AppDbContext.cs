﻿namespace Nallas.Assessment.Infrastructure.Data
{
    public class AppDbContext : DbContext, IApplicationDbContext
    {
        public DbSet<Invoice> invoices { get; set; }

        public AppDbContext(DbContextOptions<AppDbContext> dbContextOptions) : base(dbContextOptions)
        {

        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Invoice>().HasData(
                new Invoice
                {
                    Id = 1,
                    Amount = 1000
                },
                  new Invoice
                  {
                      Id = 1,
                      Amount = 1000
                  });

        }
    }


  
}
