﻿namespace Nallas.Assessment.Application.Commands.Filter
{
    public class CreateInvoiceFilterHandler : IRequestHandler<CreateInvoiceFilterCommand, InvoiceFilter>
    {
        private readonly InvoiceFilterRepository _invoiceRepository;

        public CreateInvoiceFilterHandler(InvoiceFilterRepository invoiceFilterRepository)
        {
            _invoiceFilterRepository = invoiceFilterRepository;
        }
        public Task<InvoiceFilter> Handle(CreateInvoiceFilterCommand request, CancellationToken cancellationToken)
        {
            var invoice = new InvoiceFilter
            {
                amount = request.amount,
                FromDate = request.FromDate,
                ToDate =request.ToDate,
                InvoiceName = request.InvoiceName,
                InvoiceType = request.InvoiceType,
            };


            var result = await _repo.FilterInvoice(invoice);

        }
    }
}
