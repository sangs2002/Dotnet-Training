﻿using MediatR;
namespace Nallas.Assessment.Application.Commands.Filter
{
    public class CreateInvoiceFilterCommand :IRequest<InvoiceFilter>
    {

        public string? InvoiceName { get; set; }
        public string? InvoiceType { get; set; }
        public double? amount { get; set; }
        public string? ordertype { get; set; }
        public DateTime? ToDate { get; set; }

        public DateTime? FromDate { get; set; }
    }
}
