﻿namespace Nallas.Assessment.Application.Commands.SaveInvoice
{
    public class CreateInvoiceHandler : IRequestHandler<CreateInvoiceCommand, Invoice>
    {

        private readonly InvoiceRepository _invoiceRepository;


        public CreateInvoiceHandler(InvoiceRepository invoiceRepository)
        {
            _invoiceRepository = invoiceRepository;

        }
        public Task<Invoice> Handle(CreateInvoiceCommand request, CancellationToken cancellationToken)
        {

            var invoice = new Invoice
            {
                Id = request.Id,
                amount = request.Amount
            };

            await _repo.AddAsync(invoice);

        }
    }
}
