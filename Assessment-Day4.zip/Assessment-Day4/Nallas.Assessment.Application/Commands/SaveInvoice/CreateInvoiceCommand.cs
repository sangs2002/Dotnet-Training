﻿namespace Nallas.Assessment.Application.Commands.SaveInvoice
{
    public class CreateInvoiceCommand : IRequest<Invoice>
    {
        public int Id { get; set; }
        public double Amount { get; set; }
    }
}
