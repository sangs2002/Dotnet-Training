﻿using MediatR;

namespace Nallas.Assessment.Application.Commands.PaymentType
{
    public class CreatePaymentTypeCommand : IRequest<>
    {
    }
}
