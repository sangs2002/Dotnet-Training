﻿namespace Nallas.Assessment.Application.DTOs
{
    public class InvoiceFilter
    {
     
        public string? InvoiceName { get; set; }
        public string? InvoiceType { get; set; }
        public double? amount { get; set; }
        public DateTime? ToDate { get; set; }

        public DateTime? FromDate { get; set; }

    }
}
