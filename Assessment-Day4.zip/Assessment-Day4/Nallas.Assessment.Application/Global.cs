﻿global using MediatR;
global using Nallas.Assessment.Application.DTOs;
