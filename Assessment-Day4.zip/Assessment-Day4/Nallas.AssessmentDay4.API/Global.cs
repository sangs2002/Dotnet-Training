﻿global using MediatR;
global using Microsoft.AspNetCore.Mvc;
global using Nallas.Assessment.Application.Commands.Filter;
global using Nallas.Assessment.Application.Commands.SaveInvoice;