﻿namespace Nallas.Assessment.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InvoiceController : ControllerBase
    {
        private readonly IMediator _mediator;

        public InvoiceController(IMediator mediator)
        {
            _mediator = mediator;
        }


        [HttpPost("Invoice")]

        public async Task<IActionResult> SaveInvoice(CreateInvoiceCommand createInvoiceCommand)
        {
           var result = await _mediator.Send(createInvoiceCommand);

            return Ok(result);

        }


        [HttpPost("InvoiceFilter")]

        public async Task<IActionResult> FilterInvoice(CreateInvoiceFilterCommand createInvoiceFilterCommand)
        {
            var result = await _mediator.Send(createInvoiceFilterCommand);

            return Ok(result);

        }
    }
}
