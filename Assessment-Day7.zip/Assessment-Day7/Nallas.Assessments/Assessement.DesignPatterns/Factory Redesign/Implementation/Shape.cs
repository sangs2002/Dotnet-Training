﻿namespace Nallas.Assessment.Day7.Factory_Redesign.Implementation
{
    public class Shape
    {
        public class Circle : IShape
        {
            public void draw()
            {
                Console.WriteLine("Drawing Circle");
            }
        }

        public class Square : IShape
        {
            public void draw()
            {
                Console.WriteLine("Drawing Square");
            }
        }


    }
}
