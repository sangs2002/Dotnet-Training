﻿namespace Nallas.Assessment.Day7.Factory_Redesign.Factory
{
    public static class ShapeFactory2
    {
        public static T create<T>() where T : IShape, new()
        {
            return new T();
        }
    }
}
