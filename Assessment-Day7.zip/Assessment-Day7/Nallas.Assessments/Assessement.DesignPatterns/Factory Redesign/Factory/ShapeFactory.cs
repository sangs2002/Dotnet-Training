﻿namespace Assessment.DesignPatterns.Factory_Redesign.Factory
{
    public class ShapeFactory
    {
        private static readonly Dictionary<string, Func<IShape>> _map = new Dictionary<string, Func<IShape>>
        {

            { "Circle", () => new Circle() },
            { "Square", () => new Square() }
        };


        public static IShape Create(string type)
        {
        
                if (_map.TryGetValue(type, out Func<IShape> creator))
                {
                    return creator();
                }
            

                throw new ArgumentException("Invalid shape type");
            

          
        }
    }
}
