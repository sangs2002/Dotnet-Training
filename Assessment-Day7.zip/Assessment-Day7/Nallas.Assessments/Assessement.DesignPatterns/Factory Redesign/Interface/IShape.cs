﻿namespace Nallas.Assessment.Day7.Factory_Redesign.Interface
{
    public interface IShape
    {
        void draw();
    }
}
