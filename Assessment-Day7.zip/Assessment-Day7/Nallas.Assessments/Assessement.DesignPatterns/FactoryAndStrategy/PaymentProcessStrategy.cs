﻿

namespace Nallas.Assessment.Day7.Factory
{
    public  class PaymentProcessStrategy
    {

        private readonly IPayment _payment;
        private PaymentProcessCircuitBreaker _circuitBreaker => new PaymentProcessCircuitBreaker();

        public PaymentProcessStrategy(IPayment payment)
        {
            _payment = payment;
        }


        public void ExecutePayment()
        {
            _payment.Payment();
        }

        public void Circuit(IPayment payment)
        {
            _circuitBreaker.Execute(() =>
            {
                payment.Payment();
            });
        }


    }
}
