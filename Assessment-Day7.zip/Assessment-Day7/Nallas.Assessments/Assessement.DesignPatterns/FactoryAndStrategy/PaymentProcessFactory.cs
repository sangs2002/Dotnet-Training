﻿
namespace Nallas.Assessment.Day7.Factory
{
     public class PaymentProcessFactory
    {
        public static IPayment CreatePayment(string paymentType)
        {
            return paymentType switch
            {
                "Credit" => new CreditProcess(),
                "Paypal" => new PaypalProcess(),
                _ => throw new ArgumentException("Invalid payment type")

            };
        }
    }
}
