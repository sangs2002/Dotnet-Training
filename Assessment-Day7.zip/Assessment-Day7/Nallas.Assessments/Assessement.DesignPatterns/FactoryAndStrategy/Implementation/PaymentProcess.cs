﻿namespace Nallas.Assessment.Day7.Factory.Implementation
{
    public class PaymentProcess
    {

        public class CreditProcess : IPayment
        {
            public void Payment()
            {
                Console.WriteLine("Credit cared payment");
            }
        }


        public class PaypalProcess : IPayment
        {
            public void Payment()
            {
                Console.WriteLine("paypal payment");
            }
        }
    }
}
