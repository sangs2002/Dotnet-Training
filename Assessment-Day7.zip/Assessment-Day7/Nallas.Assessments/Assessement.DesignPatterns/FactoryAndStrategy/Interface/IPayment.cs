﻿namespace Nallas.Assessment.Day7.Factory.Interface
{
    public interface IPayment
    {
        void Payment();
    }
}
