﻿
global using Assessment.DesignPatterns.CircuitBreaker;
global using Assessment.DesignPatterns.Factory.Interface;
global using static Assessment.DesignPatterns.Factory.Implementation.PaymentProcess;
global using Assessment.DesignPatterns.Factory;
global using Assessment.DesignPatterns.Factory_Redesign.Factory;
global using Assessment.DesignPatterns.Factory_Redesign.Interface;
global using static Assessment.DesignPatterns.Factory_Redesign.Implementation.Shape;
global using Assessment.DesignPatterns.Singleton;
