﻿namespace Assessment.DesignPatterns.CircuitBreaker
{
    public class PaymentProcessCircuitBreaker
    {
        private int failureCount = 0;
        public const int maxcount = 3;

        private DateTime lastFailureTime;
        private readonly TimeSpan waitTime = TimeSpan.FromSeconds(10);

        public void Execute(Action action)
        {
            if (failureCount >= maxcount)
            {
                if (DateTime.Now - lastFailureTime < waitTime)
                {
                    Console.WriteLine("service is temporarily blocked.");
                    return;
                }

                failureCount = 0;
            }

            try
            {
                action();
            }

            catch
            {
                failureCount++;
                lastFailureTime = DateTime.Now;
                throw;
            }

        }
    }
}