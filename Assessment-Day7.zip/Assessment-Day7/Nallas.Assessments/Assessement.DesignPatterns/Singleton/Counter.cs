﻿namespace Assessment.DesignPatterns.Singleton
{
    public class Counter
    {

        private static Counter _counter = new Counter();

        private Counter()
        {

        }

        public static Counter counter => _counter;


        public int value { get; set; }

    }
}
    