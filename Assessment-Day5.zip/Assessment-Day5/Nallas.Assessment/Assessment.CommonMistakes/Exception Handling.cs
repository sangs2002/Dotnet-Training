﻿using Nallas.Assessment.Day_5.Model;

namespace Nallas.Assessment.Day_5
{
    public class Exception_Handling
    {
        public void Transfer (Account from, Account to, decimal amount)
        {
            if(amount <= 0)
            {
                throw new ArgumentOutOfRangeException("Amount should not be negative"+ nameof(amount));
            }

            if (from.balance < amount)
            {
                throw new ArgumentNullException("Insuffient balance");
            }
        }
    }
}
