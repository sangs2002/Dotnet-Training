﻿namespace Nallas.Assessment.Day_5.Model
{
    public class Account
    {
        public decimal amount { get; set; }
        public int balance { get; set; }
    }
}
