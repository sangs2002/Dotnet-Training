﻿using Nallas.Assessment.Day_5;

class Program
{
    public static async Task Main(string[] args)
    {
        ////Threads
        Thread thread = new Thread(() =>
        {
            Console.WriteLine("running on thread" + Thread.CurrentThread.ManagedThreadId);
        });

        //thread.Start();

        for (int i = 0; i < 5; i++)
        {
            new Thread(() =>
            {
                Console.WriteLine("Thread: " + Thread.CurrentThread.ManagedThreadId);
            }).Start();
        }



        ////Threads POOL

        ThreadPool.QueueUserWorkItem(_ =>
        {
            Console.WriteLine("Thread Pool:" + Thread.CurrentThread.ManagedThreadId);
        });

        for (int i = 0; i < 5; i++)
        {
            ThreadPool.QueueUserWorkItem(_ =>
            {
                Console.WriteLine("ThreadPool: " + Thread.CurrentThread.ManagedThreadId);
            });
        }

        ////TPL

        Task.Run(() =>
        {
            Console.WriteLine($"Task running on thread {Thread.CurrentThread.ManagedThreadId}");
        });

        //Parellel
        Parallel.For(1, 5, i =>
        {
            Console.WriteLine($"i={i}, Thread={Thread.CurrentThread.ManagedThreadId}");
        });



        //Delegate

        DelegateProgram delegatess = new DelegateProgram();

        int delegatea = await delegatess.GetId();


        //Call stack

        CallStack callStack = new CallStack();
        int id = 10;
        callStack.id(id);

        //Loops and Control Flow mistakes

        List<int> numbers = new() { 1, 2, 3, 4 };

        //foreach (var n in numbers)
        //{
        //    if (n == 3)
        //        numbers.Remove(n);  //Runtime error
        //}

        int[] arr = { 10, 20, 30 };

        for (int i = 0; i <= arr.Length; i++)
        {
            Console.WriteLine(arr[i]);
        }


    }
}