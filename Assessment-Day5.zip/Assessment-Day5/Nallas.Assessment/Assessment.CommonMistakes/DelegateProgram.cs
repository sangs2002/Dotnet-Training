﻿namespace Nallas.Assessment.Day_5
{
    public class DelegateProgram
    {
        private Func<Task<int>> GetFunc;

        public DelegateProgram()
        {
            GetFunc = GetId;
        }

        public async Task<int> GetId()
        {
            await Task.Delay(3000);
            return 10;
        }
    }
}
