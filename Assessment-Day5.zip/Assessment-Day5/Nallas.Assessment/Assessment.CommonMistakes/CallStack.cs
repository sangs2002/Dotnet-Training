﻿namespace Nallas.Assessment.Day_5
{
    public class CallStack
    {


        public void id(int id)
        {
           int ids = getid(id);
        }

        public int getid(int id)
        {
            Console.WriteLine($"Id is {id}");
            return id;
        }
    }
}
