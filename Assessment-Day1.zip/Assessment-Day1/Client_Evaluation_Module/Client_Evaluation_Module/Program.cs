﻿using Client_Evaluation_Module.Data;
using Client_Evaluation_Module.Services;

class Program
{
    static void Main(string[] args)
    {
        var people = new PersonDbSet().Data();
        var evaluator = new TierClassificationService();

        var evaluatedClients = people
             .Where(p => EligibilityService.IsEligible(p.Age))
             .Select(p =>
             {
                 p.ClientTier = evaluator.Evaluate(p);
                 RiskEvaluationService.ApplyRisk(p);
                 return p;
             })
             .ToList();

        foreach (var client in evaluatedClients)
        {
                       Console.WriteLine($"Name: {client.Name}, Age: {client.Age}, Tier: {client.ClientTier}, Risk: {client.RiskLevel}");
        }

    }
}