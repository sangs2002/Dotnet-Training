﻿using Client_Evaluation_Module.Model;

namespace Client_Evaluation_Module.Interface
{
    public interface IEligibility
    {
        bool IsEligible(Person person);
    }
}
