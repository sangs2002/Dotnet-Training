﻿using Client_Evaluation_Module.Model;

namespace Client_Evaluation_Module.Interface
{
    public interface IRiskEvaluation
    {
        void Evaluate(Person person);
    }
}
