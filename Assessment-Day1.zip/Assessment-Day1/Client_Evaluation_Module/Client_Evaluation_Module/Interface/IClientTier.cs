﻿
using Client_Evaluation_Module.Constants;
using Client_Evaluation_Module.Enum;
using Client_Evaluation_Module.Model;


namespace Client_Evaluation_Module.Interface
{

        public interface IClientTier
        {
            bool IsMatch(Person person);
            ClientTier GetTier();
        }

        public class SeniorClientTier : IClientTier
        {
            public bool IsMatch(Person person)
            {
                return person.Age >= 60;
            }
            public ClientTier GetTier()
            {
                return ClientTier.SeniorTier;
            }
        }

        public class CareTier : IClientTier
        {
            public bool IsMatch(Person person)
            {
                return person.HasHealthChallenges == true;
            }
            public ClientTier GetTier()
            {
                return ClientTier.CareTier;
            }
        }

        public class FamilyTier : IClientTier
        {
            public bool IsMatch(Person person)
            {
                return person.NumberOfDependents > 3;
            }
            public ClientTier GetTier()
            {
                return ClientTier.FamilyTier;
            }
        }

        public class PremiumRule : IClientTier
        {
            public bool IsMatch(Person person)
            {
                return person.AnnualIncome > ClientConstants.PremiumIncome;

            }

            public ClientTier GetTier()
            {
                return ClientTier.PreminumTier;

            }
        }
    }

