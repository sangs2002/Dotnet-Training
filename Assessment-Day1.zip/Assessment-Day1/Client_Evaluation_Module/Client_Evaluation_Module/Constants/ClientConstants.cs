﻿namespace Client_Evaluation_Module.Constants
{
    public class ClientConstants
    {
        public const int MinAge = 18;
        public const int MaxAge = 75;
        public const int SeniorAge = 60;
        public const int FamilyDependents = 3;
        public const decimal PremiumIncome = 1_000_000m;
    }
}
