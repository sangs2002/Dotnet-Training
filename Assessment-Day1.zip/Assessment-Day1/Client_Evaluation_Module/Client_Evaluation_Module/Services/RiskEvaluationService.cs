﻿using Client_Evaluation_Module.Enum;
using Client_Evaluation_Module.Interface;
using Client_Evaluation_Module.Model;

namespace Client_Evaluation_Module.Services
{
    public  class RiskEvaluationService : IRiskEvaluation
    {
        //public static void ApplyRisk(Person person)
        //{
        //    if (person.HasPreviousClaims && person.Age >= 40)
        //    {
        //        if (person.ClientTier > ClientTier.StandardTier)
        //            person.ClientTier--;
        //    }

        //    person.RiskLevel =
        //        (person.HasHealthChallenges && person.HasPreviousClaims)
        //        ? RiskLevel.High
        //        : RiskLevel.low;
        //}
               public void Evaluate(Person person)
        {
            if (person.HasPreviousClaims && person.Age >= 40)
            {
                if (person.ClientTier > ClientTier.StandardTier)
                   person.ClientTier--;
            }

           
            if (person.HasHealthChallenges && person.HasPreviousClaims)
            {
                person.RiskLevel = RiskLevel.High;
            }
            else
            {
                person.RiskLevel = RiskLevel.low;
            }
        }
    }


    }

