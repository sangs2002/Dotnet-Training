﻿using Client_Evaluation_Module.Enum;
using Client_Evaluation_Module.Interface;
using Client_Evaluation_Module.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace Client_Evaluation_Module.Services
{
    public class ClientEvaluationEngine
    {

        private readonly IEnumerable<IEligibility> _eligibilityRules;
        private readonly IEnumerable<IClientTier> _tierRules;
        private readonly IRiskEvaluation _riskEvaluator;

        public ClientEvaluationEngine(
            IEnumerable<IEligibility> eligibilityRules,
            IEnumerable<IClientTier> tierRules,
            IRiskEvaluation riskEvaluator)
        {
            _eligibilityRules = eligibilityRules;
            _tierRules = tierRules;
            _riskEvaluator = riskEvaluator;
        }

        public Person Evaluate(Person person)
        {

            var tier = _tierRules
                .First(r => r.IsMatch(person))
                .GetTier();

            _riskEvaluator.Evaluate(tier);
            _riskEvaluator.Evaluate(person);

            return person;
        }
    }
}
