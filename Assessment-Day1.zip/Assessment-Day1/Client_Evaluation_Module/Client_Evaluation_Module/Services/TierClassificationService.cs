﻿using Client_Evaluation_Module.Enum;
using Client_Evaluation_Module.Interface;
using Client_Evaluation_Module.Model;

namespace Client_Evaluation_Module.Services
{
    public class TierClassificationService
    {
        private readonly List<IClientTier> _tierRules;

        public TierClassificationService()
        {
            _tierRules = new List<IClientTier>
            {
                new SeniorClientTier(),
                new CareTier(),
                new FamilyTier(),
                new PremiumRule()
            };
        }

        public ClientTier Evaluate(Person person)
        {
            foreach (var rule in _tierRules)
            {
                if (rule.IsMatch(person))
                {
                    return rule.GetTier();
                }
            }
            return ClientTier.StandardTier;
        }
    }
}
