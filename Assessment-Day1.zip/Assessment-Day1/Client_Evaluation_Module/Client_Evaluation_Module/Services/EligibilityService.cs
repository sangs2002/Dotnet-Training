﻿using Client_Evaluation_Module.Constants;
using Client_Evaluation_Module.Interface;
using Client_Evaluation_Module.Model;

namespace Client_Evaluation_Module.Services
{

    //public static class EligibilityService
    //{
    //    public static bool IsEligible(int age)
    //    {
    //        return age >= ClientConstants.MinAge &&
    //               age <= ClientConstants.MaxAge;
    //    }
    //}

    public class Eligibility : IEligibility
    {
        public bool IsEligible(Person person)
        {
            return person.Age >= ClientConstants.MinAge &&
                   person.Age <= ClientConstants.MaxAge;
        }
    }
}

