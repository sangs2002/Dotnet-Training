﻿using Client_Evaluation_Module.Enum;
using Client_Evaluation_Module.Interface;

namespace Client_Evaluation_Module.Implementation
{
    public class TierClassificationService
    {

        private readonly List<IClientTier> _tierRules;

        public TierClassificationService()
        {
            _tierRules = new List<IClientTier>
            {
                new SeniorClientTier(),
                new CareTier(),
                new FamilyTier(),
                new PremiumRule()
            };
        }

        public ClientTier ClassifyTier(Model.Person person)
        {
            foreach (var rule in _tierRules)
            {
                if (rule.IsMatch(person))
                {
                    return rule.GetTier();
                }
            }
            return ClientTier.NotEligible;
        }

    }
}
