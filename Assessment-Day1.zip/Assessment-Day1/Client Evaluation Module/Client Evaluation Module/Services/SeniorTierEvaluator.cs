﻿using Client_Evaluation_Module.Enum;
using Client_Evaluation_Module.Model;

namespace Client_Evaluation_Module.Services
{
    public class SeniorTierEvaluator : ClientEvaluator
    {


        protected override RiskLevel CalculateRiskLevel(Person person)
        {
            throw new NotImplementedException();
        }

        protected override ClientTier CalculateTier(Person person)
        {
            throw new NotImplementedException();
        }

        protected override bool IsEligible(Person person)
        {
            throw new NotImplementedException();
        }
    }
}
