﻿using Client_Evaluation_Module.Model;

namespace Client_Evaluation_Module.Services
{
    public interface IClientEvaluator
    {
        Person EvaluateClient(Person person);
    }
}
