﻿using Client_Evaluation_Module.Constants;
using Client_Evaluation_Module.Enum;
using Client_Evaluation_Module.Model;
using System.Reflection.Metadata;

namespace Client_Evaluation_Module.Services
{
    public abstract class ClientEvaluator : IClientEvaluator
    {

        public Person EvaluateClient(Person person)
        {
            person.ClientTier = DetermineTier(person);
            person.RiskLevel = DetermineRisk(person);

            ApplyClaimAdjustments(person);

            return person;
        }


        protected virtual bool IsEligible(Person person)
        {
            return person.Age >= ClientConstants.MinAge &&
               person.Age <= ClientConstants.MaxAge;
        }


        protected abstract ClientTier DetermineTier(Person person);
        protected virtual RiskLevel DetermineRisk(Person person)
        {
            if (person.HasHealthChallenges && person.HasPreviousClaims)
                return RiskLevel.High;

            return RiskLevel.low;
        }

        protected virtual void ApplyClaimAdjustments(Person person)
        {
            if (person.HasPreviousClaims && person.Age >= 40 &&
                person.ClientTier > ClientTier.StandardTier)
            {
                person.ClientTier -= 1; 
            }
        }

    }
}
