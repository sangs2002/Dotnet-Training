﻿namespace Client_Evaluation_Module.Enum
{
    public enum RiskLevel
    {
        High = 1,
        low = 2,
    }
}
