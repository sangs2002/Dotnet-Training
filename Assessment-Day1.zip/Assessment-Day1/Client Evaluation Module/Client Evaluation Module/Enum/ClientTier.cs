﻿namespace Client_Evaluation_Module.Enum
{
    public enum ClientTier
    {
        NotEligible = 0,
        StandardTier = 1,
        SeniorTier = 2,
        CareTier = 3,
        FamilyTier = 4,
        PreminumTier = 5,

    }
}
