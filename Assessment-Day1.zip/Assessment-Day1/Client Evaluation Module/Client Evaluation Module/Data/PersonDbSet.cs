﻿using Client_Evaluation_Module.Model;

namespace Client_Evaluation_Module.Data
{
    public class PersonDbSet
    {
        public List<Person> Data()
        {
            return new List<Person>
            {
                new Person("prabu", 61, false, 2, 60000m, false),
                new Person("Prasanth", 25, true, 1, 40000m, false),
                new Person("Ranjith", 40, false, 3, 70000m, true),
                new Person("Moove", 35, false, 4, 80000m, false),
                new Person("Abishek", 74, true, 1, 1000000m, false),
            };
        }
    }
}
