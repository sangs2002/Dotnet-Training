﻿using Client_Evaluation_Module.Enum;

namespace Client_Evaluation_Module.Model
{

        public class Person
        {

             public string? Name { get; private set; }
             public int Age { get; set; }
             public bool HasHealthChallenges { get; set; }

            public int NumberOfDependents { get; set; }

            public decimal AnnualIncome { get; set; }

            public bool HasPreviousClaims { get; set; }

            public ClientTier ClientTier { get; set; }

            public RiskLevel RiskLevel { get; set; }


            public Person(string name, int _age, bool _HasHealthChallenges, int _NumberOfDependents, decimal _AnnualIncome, bool _HasPreviousClaims)
            {
                Name = name;
                Age = _age;
                HasHealthChallenges = _HasHealthChallenges;
                NumberOfDependents = _NumberOfDependents;
                AnnualIncome = _AnnualIncome;
                HasPreviousClaims = _HasPreviousClaims;
            }





        }
    }

