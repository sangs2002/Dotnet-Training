﻿using Client_Evaluation_Module.Data;
using Client_Evaluation_Module.Implementation;
using Client_Evaluation_Module.Model;
using Client_Evaluation_Module.Services;

class Program
{
       static void Main(string[] args)
    {
        PersonDbSet personData = new PersonDbSet();
        List<Person> person = personData.Data();



        IClientEvaluator evaluator = new TierClassificationService();

        person.Select()
    }

}